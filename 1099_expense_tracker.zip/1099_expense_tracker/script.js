/* 1099 Expense Tracker
 * This script handles state management for categories and expenses,
 * persists data to localStorage, renders forms and tables, and
 * registers a service worker for offline capability.
 */

// Global arrays for categories and expenses
let categories = [];
let expenses = [];
let editingId = null; // When editing an expense

// DOM elements
const expenseForm = document.getElementById('expenseForm');
const categorySelect = document.getElementById('expenseCategory');
const filterSelect = document.getElementById('filterCategory');
const addCategoryBtn = document.getElementById('addCategoryBtn');
const categoryModal = new bootstrap.Modal(document.getElementById('categoryModal'));
const categoryForm = document.getElementById('categoryForm');
const newCategoryInput = document.getElementById('newCategoryName');
const expensesTableBody = document.getElementById('expensesTableBody');
const summaryCard = document.getElementById('summaryCard');
const summaryContent = document.getElementById('summaryContent');
const expensesCard = document.getElementById('expensesCard');
const exportButton = document.getElementById('exportButton');
const receiptModal = new bootstrap.Modal(document.getElementById('receiptModal'));
const receiptModalImage = document.getElementById('receiptModalImage');

// Utility functions
function loadCategories() {
  const stored = localStorage.getItem('expenseTrackerCategories');
  if (stored) {
    try {
      categories = JSON.parse(stored);
    } catch (e) {
      console.error('Failed to parse categories:', e);
      categories = [];
    }
  }
  // Initialize with defaults if empty
  if (!categories || categories.length === 0) {
    categories = ['Gas', 'Food', 'Mileage', 'Car Upkeep', 'Other'];
    saveCategories();
  }
  populateCategorySelects();
}

function saveCategories() {
  localStorage.setItem('expenseTrackerCategories', JSON.stringify(categories));
}

function populateCategorySelects() {
  // Expense form select
  categorySelect.innerHTML = '';
  categories.forEach((cat) => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    categorySelect.appendChild(opt);
  });
  // Filter select
  filterSelect.innerHTML = '';
  const allOpt = document.createElement('option');
  allOpt.value = 'all';
  allOpt.textContent = 'All';
  filterSelect.appendChild(allOpt);
  categories.forEach((cat) => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    filterSelect.appendChild(opt);
  });
}

function loadExpenses() {
  const stored = localStorage.getItem('expenseTrackerExpenses');
  if (stored) {
    try {
      expenses = JSON.parse(stored);
    } catch (e) {
      console.error('Failed to parse expenses:', e);
      expenses = [];
    }
  }
  renderExpenses();
  renderSummary();
}

function saveExpenses() {
  localStorage.setItem('expenseTrackerExpenses', JSON.stringify(expenses));
}

function toBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function clearForm() {
  expenseForm.reset();
  editingId = null;
  expenseForm.querySelector('button[type="submit"]').textContent = 'Add Expense';
}

function handleFormSubmit(event) {
  event.preventDefault();
  const date = document.getElementById('expenseDate').value;
  const category = categorySelect.value;
  const amountVal = document.getElementById('expenseAmount').value;
  const amount = parseFloat(amountVal);
  const vendor = document.getElementById('expenseVendor').value.trim();
  const description = document.getElementById('expenseDescription').value.trim();
  const notes = document.getElementById('expenseNotes').value.trim();
  const receiptInput = document.getElementById('expenseReceipt');
  // Basic validation
  if (!date || !category || !amountVal) {
    return;
  }
  const handleSave = (receiptData) => {
    if (editingId) {
      // Update existing expense
      const idx = expenses.findIndex((exp) => exp.id === editingId);
      if (idx >= 0) {
        expenses[idx] = {
          ...expenses[idx],
          date,
          category,
          amount,
          vendor,
          description,
          notes,
          receipt: receiptData || expenses[idx].receipt,
        };
      }
    } else {
      // Create new expense
      const id = Date.now();
      expenses.push({ id, date, category, amount, vendor, description, notes, receipt: receiptData || null });
    }
    saveExpenses();
    renderExpenses();
    renderSummary();
    clearForm();
    // Reset file input preview
    receiptInput.value = '';
  };
  // Handle receipt file
  if (receiptInput.files && receiptInput.files.length > 0) {
    const file = receiptInput.files[0];
    toBase64(file).then((data) => handleSave(data));
  } else {
    handleSave(null);
  }
}

function renderExpenses() {
  // Determine filter
  const filter = filterSelect.value;
  const filteredExpenses = expenses.filter((exp) => {
    return filter === 'all' || exp.category === filter;
  });
  // Sort by date descending
  filteredExpenses.sort((a, b) => new Date(b.date) - new Date(a.date));
  expensesTableBody.innerHTML = '';
  if (filteredExpenses.length === 0) {
    expensesCard.style.display = 'none';
    return;
  }
  expensesCard.style.display = '';
  filteredExpenses.forEach((exp) => {
    const tr = document.createElement('tr');
    // Date
    const tdDate = document.createElement('td');
    tdDate.textContent = exp.date;
    tr.appendChild(tdDate);
    // Category
    const tdCat = document.createElement('td');
    tdCat.textContent = exp.category;
    tr.appendChild(tdCat);
    // Description
    const tdDesc = document.createElement('td');
    tdDesc.textContent = exp.description || '';
    tr.appendChild(tdDesc);
    // Amount
    const tdAmount = document.createElement('td');
    tdAmount.textContent = '$' + exp.amount.toFixed(2);
    tr.appendChild(tdAmount);
    // Receipt thumbnail
    const tdReceipt = document.createElement('td');
    if (exp.receipt) {
      const img = document.createElement('img');
      img.src = exp.receipt;
      img.className = 'receipt-thumb';
      img.alt = 'receipt';
      img.addEventListener('click', () => {
        receiptModalImage.src = exp.receipt;
        receiptModal.show();
      });
      tdReceipt.appendChild(img);
    } else {
      tdReceipt.textContent = '-';
    }
    tr.appendChild(tdReceipt);
    // Actions
    const tdActions = document.createElement('td');
    tdActions.className = 'actions-btns';
    // Edit button
    const editBtn = document.createElement('button');
    editBtn.className = 'btn btn-sm btn-outline-primary';
    editBtn.innerHTML = '<i class="bi bi-pencil"></i> Edit';
    editBtn.addEventListener('click', () => {
      beginEdit(exp.id);
    });
    tdActions.appendChild(editBtn);
    // Delete button
    const delBtn = document.createElement('button');
    delBtn.className = 'btn btn-sm btn-outline-danger';
    delBtn.innerHTML = '<i class="bi bi-trash"></i> Delete';
    delBtn.addEventListener('click', () => {
      if (confirm('Delete this expense?')) {
        expenses = expenses.filter((e) => e.id !== exp.id);
        saveExpenses();
        renderExpenses();
        renderSummary();
      }
    });
    tdActions.appendChild(delBtn);
    tr.appendChild(tdActions);
    expensesTableBody.appendChild(tr);
  });
}

function renderSummary() {
  if (expenses.length === 0) {
    summaryCard.style.display = 'none';
    summaryContent.innerHTML = '';
    return;
  }
  summaryCard.style.display = '';
  // Compute totals
  const totals = {};
  let grandTotal = 0;
  expenses.forEach((exp) => {
    totals[exp.category] = (totals[exp.category] || 0) + exp.amount;
    grandTotal += exp.amount;
  });
  // Build table
  let html = '<table class="table table-bordered mb-0"><thead><tr><th>Category</th><th>Total ($)</th></tr></thead><tbody>';
  Object.keys(totals).forEach((cat) => {
    html += `<tr><td>${cat}</td><td>$${totals[cat].toFixed(2)}</td></tr>`;
  });
  html += `<tr class="fw-bold"><td>Total</td><td>$${grandTotal.toFixed(2)}</td></tr>`;
  html += '</tbody></table>';
  summaryContent.innerHTML = html;
}

function beginEdit(id) {
  const expense = expenses.find((exp) => exp.id === id);
  if (!expense) return;
  editingId = id;
  document.getElementById('expenseDate').value = expense.date;
  categorySelect.value = expense.category;
  document.getElementById('expenseAmount').value = expense.amount;
  document.getElementById('expenseVendor').value = expense.vendor || '';
  document.getElementById('expenseDescription').value = expense.description || '';
  document.getElementById('expenseNotes').value = expense.notes || '';
  // We do not pre-fill the receipt input; user can choose a new one to replace
  expenseForm.querySelector('button[type="submit"]').textContent = 'Update Expense';
  // Scroll to form
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function exportCSV() {
  if (expenses.length === 0) return;
  const header = ['id', 'date', 'category', 'amount', 'vendor', 'description', 'notes'];
  const rows = [header];
  expenses.forEach((exp) => {
    rows.push([
      exp.id,
      exp.date,
      exp.category,
      exp.amount.toFixed(2),
      exp.vendor || '',
      exp.description || '',
      exp.notes || '',
    ]);
  });
  const csvContent = rows
    .map((row) =>
      row
        .map((value) => {
          // Escape quotes and commas
          const str = String(value);
          if (str.includes(',') || str.includes('"')) {
            return '"' + str.replace(/"/g, '""') + '"';
          }
          return str;
        })
        .join(',')
    )
    .join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const now = new Date();
  const timestamp = now.toISOString().split('T')[0];
  link.download = `expenses_${timestamp}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Event listeners
expenseForm.addEventListener('submit', handleFormSubmit);
filterSelect.addEventListener('change', () => {
  renderExpenses();
});
addCategoryBtn.addEventListener('click', () => {
  newCategoryInput.value = '';
  categoryModal.show();
});
categoryForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const newCat = newCategoryInput.value.trim();
  if (newCat && !categories.includes(newCat)) {
    categories.push(newCat);
    saveCategories();
    populateCategorySelects();
  }
  categoryModal.hide();
});
exportButton.addEventListener('click', exportCSV);

// Service Worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('service-worker.js')
      .catch((error) => console.error('SW registration failed:', error));
  });
}

// Load data on startup
window.addEventListener('DOMContentLoaded', () => {
  loadCategories();
  loadExpenses();
});